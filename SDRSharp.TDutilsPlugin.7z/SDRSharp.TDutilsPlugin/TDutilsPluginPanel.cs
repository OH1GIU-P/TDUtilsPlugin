﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using SDRSharp.Common;

namespace SDRSharp.TDutilsPlugin
{
    public partial class TDutilsPluginPanel : UserControl
    {
        public delegate bool WindowEnumDelegate(IntPtr hwnd, int lParam);

        [DllImport("user32.dll")]
        static extern IntPtr FindWindow(StringBuilder lpClassName, StringBuilder lpWindowName);
        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int wMsg, int wParam, StringBuilder lParam);
        [DllImport("user32.dll")]
        private static extern int GetWindowText(int hWnd, StringBuilder lpString, int length);
        [DllImport("user32.dll")]
        private static extern int GetWindowTextLength(int hWnd);
        [DllImport("user32.dll")]
        public static extern int EnumChildWindows(IntPtr hwnd, WindowEnumDelegate del, int lParam);
        [DllImport("user32.dll")]
        static extern uint RealGetWindowClass(IntPtr hwnd, StringBuilder pszType, uint cchType);
        [DllImport("user32.dll")]
        static extern void SwitchToThisWindow(IntPtr hWnd, bool turnOn);
        [DllImport("user32.dll")]
        static extern bool SetForegroundWindow(IntPtr hWnd);

        StringBuilder _netInfoWin = new StringBuilder("Network Info");
        StringBuilder _netinfo = new StringBuilder();

        const int WM_GETTEXT = 13;
        const int WM_GETTEXTLENGTH = 14;
        private ISharpControl _control;

        public TDutilsPluginPanel(ISharpControl control)
        {
            InitializeComponent();
            _control = control;
            labelFileName.Text = string.Empty;
        }

        private void buttonFindNetInfo_Click(object sender, EventArgs e)
        {
            IntPtr hwnd = IntPtr.Zero;
            labelFileName.Text = string.Empty;
            hwnd = FindWindow(null, _netInfoWin);
            if (hwnd == IntPtr.Zero)
            {
                MessageBox.Show("Cannot find Network Info window", Utils._caption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string logFile = Application.StartupPath + "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "_" + _control.Frequency.ToString();
                _netinfo.Clear();
                WindowEnumDelegate del = new WindowEnumDelegate(WindowEnumProc);
                logFile += ".txt";
                if (checkBoxGridCopy.Checked)
                {
                    Clipboard.Clear();
                    SwitchToThisWindow(hwnd, true);
                    SetForegroundWindow(hwnd);
                    SendKeys.SendWait("{TAB}");
                    SendKeys.SendWait("^a");
                    SendKeys.SendWait("^c");
                    try
                    {
                        if (Clipboard.ContainsText())
                        {
                            File.WriteAllText(logFile, Clipboard.GetText());
                            labelFileName.Text = logFile;
                        }
                    }
                    catch
                    {
                    }
                }
                else
                {
                    EnumChildWindows(hwnd, del, 0);
                    File.WriteAllText(logFile, _netinfo.ToString());
                    labelFileName.Text = logFile;
                }
            }
        }

        private bool WindowEnumProc(IntPtr ctrl, int lParam)
        {
            int len = 0;
            StringBuilder data;

            len = SendMessage(ctrl, WM_GETTEXTLENGTH, 0, null);
            if (len != 0)
            {
                data = new StringBuilder(len);
                SendMessage(ctrl, WM_GETTEXT, (len + 1), data);
                _netinfo.Append(data);
            }
            return true;
        }

    }
}
