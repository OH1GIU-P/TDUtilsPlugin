﻿using System.Reflection;

namespace SDRSharp.TDutilsPlugin
{
    class Utils
    {
        public const string _caption = "TDutilsPlugin";

        public static string Version()
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            return assembly.GetName().Version.ToString();
        }
    }
}
