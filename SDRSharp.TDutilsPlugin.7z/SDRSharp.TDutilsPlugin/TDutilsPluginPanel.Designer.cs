﻿namespace SDRSharp.TDutilsPlugin
{
    partial class TDutilsPluginPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCapture = new System.Windows.Forms.Button();
            this.labelFileName = new System.Windows.Forms.Label();
            this.checkBoxGridCopy = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // buttonCapture
            // 
            this.buttonCapture.Location = new System.Drawing.Point(6, 22);
            this.buttonCapture.Name = "buttonCapture";
            this.buttonCapture.Size = new System.Drawing.Size(70, 23);
            this.buttonCapture.TabIndex = 0;
            this.buttonCapture.Text = "Capture";
            this.buttonCapture.UseVisualStyleBackColor = true;
            this.buttonCapture.Click += new System.EventHandler(this.buttonFindNetInfo_Click);
            // 
            // labelFileName
            // 
            this.labelFileName.AutoSize = true;
            this.labelFileName.Location = new System.Drawing.Point(6, 54);
            this.labelFileName.MaximumSize = new System.Drawing.Size(144, 96);
            this.labelFileName.Name = "labelFileName";
            this.labelFileName.Size = new System.Drawing.Size(20, 13);
            this.labelFileName.TabIndex = 1;
            this.labelFileName.Text = "file";
            // 
            // checkBoxGridCopy
            // 
            this.checkBoxGridCopy.AutoSize = true;
            this.checkBoxGridCopy.Location = new System.Drawing.Point(84, 25);
            this.checkBoxGridCopy.Name = "checkBoxGridCopy";
            this.checkBoxGridCopy.Size = new System.Drawing.Size(71, 17);
            this.checkBoxGridCopy.TabIndex = 1;
            this.checkBoxGridCopy.Text = "Grid copy";
            this.checkBoxGridCopy.UseVisualStyleBackColor = true;
            // 
            // TDutilsPluginPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.checkBoxGridCopy);
            this.Controls.Add(this.labelFileName);
            this.Controls.Add(this.buttonCapture);
            this.Name = "TDutilsPluginPanel";
            this.Size = new System.Drawing.Size(176, 160);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCapture;
        private System.Windows.Forms.Label labelFileName;
        private System.Windows.Forms.CheckBox checkBoxGridCopy;
    }
}
